@extends('frontend.layouts.main')
@section('main-container')

<section class="subpage-title-wrapper c-section-bg">
    <div class="container">
        <div class="breadcrumbs-wrapper">
            <ul class="breadcrumbs">
                <li><a href="index">Home</a></li>
                <li class="breadcrumb-current"><span>Contact</span></li>
            </ul>
        </div>
        <h1 class="subpage-title">Contact</h1>
        <span class="subpage-subtitle">Get in touch with us if you have a question.</span>
    </div>
</section>
<section class="content-section subpage-section">
    <div class="container">
        <div class="s-content">
            <div class="contact-container standard-content-container">
                <div class="contact-wrapper">
                    <div class="row">
                        <div class="col-lg-4 col-m-mb">
                            <div class="contact-details-wrapper">
                                <div class="standard-content-title-wrapper">
                                    <h3 class="standard-content-title">Send us a message</h3>
                                </div>
                                <div class="contact-intro-wrapper">
                                    <p class="contact-intro-text">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam at lacus non diam viverra consectetur vehicula non odio. Duis et vestibulum dui. Suspendisse tellus ipsum, fermentum et libero id, rutrum gravida arcu. Morbi placerat elit tempus bibendum aliquam. Proin tempor nibh a placerat consectetur. Praesent pharetra nibh at aliquet rutrum.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="contact-form-wrapper">
                                <form id="contact-form">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="contactName" class="form-control-label">Your Name</label>
                                                <div class="form-group">
                                                    <img src="{{asset('panel/img/icons/user-rounded.svg')}}" class="img-fluid svg-icon icon-green form-input-icon" alt="User" />
                                                    <input id="contactName" type="text" class="form-control form-control-contact" name="contactName" placeholder="Your Name...">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="contactEmail" class="form-control-label">Your Email</label>
                                                <div class="form-group">
                                                    <img src="{{asset('panel/img/icons/letter.svg')}}" class="img-fluid svg-icon icon-green form-input-icon" alt="Email" />
                                                    <input id="contactEmail" type="email" class="form-control form-control-contact" name="contactEmail" autocomplete="email" placeholder="Your Email...">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="contactSubject" class="form-control-label">Subject</label>
                                        <div class="form-group">
                                            <img src="{{asset('panel/img/icons/tag-horizontal.svg')}}" class="img-fluid svg-icon icon-green form-input-icon" alt="Subject" />
                                            <input id="contactSubject" type="text" class="form-control form-control-contact" name="contactSubject" placeholder="Subject...">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="contactMessage" class="form-control-label">Message</label>
                                        <div class="auth-textarea-wrapper">
                                            <textarea name="contactMessage" id="contactMessage" class="form-control form-control-contact form-control-textarea" rows="5" placeholder="Your Message..."></textarea>
                                        </div>
                                    </div>
                                    <div class="auth-button-wrapper">
                                        <button type="submit" class="cta-btn cta-btn-acc-action">Send</button>
                                    </div>
                                    <div id="mail-status"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="before-footer-cta-wrapper">
    <div class="container">
        <div class="before-footer-cta-content">
            <div class="before-footer-cta-text">
                <span>Take this IQ test and check <br><span class="footer-cta-typed"></span></span>
            </div>
            <div class="before-footer-cta-btn-wrapper">
                <a href="quizz" class="cta-btn cta-btn-xl animate__animated animate__pulse animate__infinite">
                    <span>Start IQ Test</span>
                    <img src="{{asset('panel/img/icons/login-3.svg')}}" class="img-fluid svg-icon icon-white cta-btn-icon" alt="Icon Go" />
                </a>
            </div>
        </div>
    </div>
</div>

@endsection
