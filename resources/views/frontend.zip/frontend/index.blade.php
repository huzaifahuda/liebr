@extends('frontend.layouts.main')
@section('main-container')

    <section class="content-section hero-section">
        <div class="container">
            <div class="s-content hero-content">
                <div class="row">
                    <div class="col-lg-6 col-12 col-m-mb">
                        <span class="before-hero-title">10,193 users completed the test today</span>
                        <h1 class="hero-title">The average IQ in Spain is 108</h1>
                        <h3 class="hero-subtitle">Take this IQ test and check what is your IQ</h3>
                        <div class="hero-cta-wrapper">
                            <a href="quizz" class="cta-btn cta-btn-big">
                                <span>Start IQ Test</span>
                                <img src="{{asset('panel/img/icons/login-3.svg')}}" class="img-fluid svg-icon icon-white cta-btn-icon" alt="Icon Go" />
                            </a>
                        </div>
                        <ul class="hero-list">
                            <li><img src="{{asset('panel/img/icons/check-circle.svg')}}" class="img-fluid svg-icon icon-green hero-list-icon" alt="Checkmark" />22 Questions</li>
                            <li><img src="{{asset('panel/img/icons/check-circle.svg')}}" class="img-fluid svg-icon icon-green hero-list-icon" alt="Checkmark" />Created by the WW IQ Test Research Team</li>
                            <li><img src="{{asset('panel/img/icons/check-circle.svg')}}" class="img-fluid svg-icon icon-green hero-list-icon" alt="Checkmark" />Get your IQ Certificate</li>
                            <li><img src="{{asset('panel/img/icons/check-circle.svg')}}" class="img-fluid svg-icon icon-green hero-list-icon" alt="Checkmark" />Get Detailed Performance Report</li>
                        </ul>
                    </div>
                    <div class="col-lg-6 col-12">
                        <img src="{{asset('panel/img/hero-img.png')}}" class="img-fluid hero-img" alt="Hero Image" />
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="content-section last-results-section c-section-bg">
        <div class="container">
            <div class="s-content last-results-content">
                <div class="sc-title-wrapper text-center">
                    <h2 class="section-title">Latest Results</h2>
                </div>
                <div class="last-results-wrapper">
                    <div class="row">
                        <div class="last-results-wrapper-col col-lg-4">
                            <div class="lrw-col-content">
                                <div class="lrw-item">
                                    <div class="lrw-item-l">
                                        <img src="{{asset('panel/img/flag-spain.png')}}" class="img-fluid flag-icon" alt="Spain" />
                                        <div class="lrw-item-date-name">
                                            <div class="lrw-item-date">Few moments ago</div>
                                            <div class="lrw-item-name">Carlos Pepito</div>
                                        </div>
                                    </div>
                                    <div class="lrw-item-r">
                                        <div class="lrw-item-score"><span>IQ Score:</span><span class="lrq-score-val">94</span></div>
                                    </div>
                                </div>
                                <div class="lrw-item">
                                    <div class="lrw-item-l">
                                        <img src="{{asset('panel/img/flag-spain.png')}}" class="img-fluid flag-icon" alt="Spain" />
                                        <div class="lrw-item-date-name">
                                            <div class="lrw-item-date">1min ago</div>
                                            <div class="lrw-item-name">Ines Gonzales</div>
                                        </div>
                                    </div>
                                    <div class="lrw-item-r">
                                        <div class="lrw-item-score"><span>IQ Score:</span><span class="lrq-score-val">72</span></div>
                                    </div>
                                </div>
                                <div class="lrw-item">
                                    <div class="lrw-item-l">
                                        <img src="{{asset('panel/img/flag-spain.png')}}" class="img-fluid flag-icon" alt="Spain" />
                                        <div class="lrw-item-date-name">
                                            <div class="lrw-item-date">3min ago</div>
                                            <div class="lrw-item-name">Diego Carvahlo</div>
                                        </div>
                                    </div>
                                    <div class="lrw-item-r">
                                        <div class="lrw-item-score"><span>IQ Score:</span><span class="lrq-score-val">89</span></div>
                                    </div>
                                </div>
                                <div class="lrw-item">
                                    <div class="lrw-item-l">
                                        <img src="{{asset('panel/img/flag-spain.png')}}" class="img-fluid flag-icon" alt="Spain" />
                                        <div class="lrw-item-date-name">
                                            <div class="lrw-item-date">5min ago</div>
                                            <div class="lrw-item-name">Juan Pedro</div>
                                        </div>
                                    </div>
                                    <div class="lrw-item-r">
                                        <div class="lrw-item-score"><span>IQ Score:</span><span class="lrq-score-val">99</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="last-results-wrapper-col col-lg-4">
                            <div class="lrw-col-content">
                                <div class="lrw-item">
                                    <div class="lrw-item-l">
                                        <img src="{{asset('panel/img/flag-spain.png')}}" class="img-fluid flag-icon" alt="Spain" />
                                        <div class="lrw-item-date-name">
                                            <div class="lrw-item-date">6min ago</div>
                                            <div class="lrw-item-name">Carlos Pepito</div>
                                        </div>
                                    </div>
                                    <div class="lrw-item-r">
                                        <div class="lrw-item-score"><span>IQ Score:</span><span class="lrq-score-val">71</span></div>
                                    </div>
                                </div>
                                <div class="lrw-item">
                                    <div class="lrw-item-l">
                                        <img src="{{asset('panel/img/flag-spain.png')}}" class="img-fluid flag-icon" alt="Spain" />
                                        <div class="lrw-item-date-name">
                                            <div class="lrw-item-date">8min ago</div>
                                            <div class="lrw-item-name">Ines Gonzales</div>
                                        </div>
                                    </div>
                                    <div class="lrw-item-r">
                                        <div class="lrw-item-score"><span>IQ Score:</span><span class="lrq-score-val">93</span></div>
                                    </div>
                                </div>
                                <div class="lrw-item">
                                    <div class="lrw-item-l">
                                        <img src="{{asset('panel/img/flag-spain.png')}}" class="img-fluid flag-icon" alt="Spain" />
                                        <div class="lrw-item-date-name">
                                            <div class="lrw-item-date">10min ago</div>
                                            <div class="lrw-item-name">Diego Carvahlo</div>
                                        </div>
                                    </div>
                                    <div class="lrw-item-r">
                                        <div class="lrw-item-score"><span>IQ Score:</span><span class="lrq-score-val">96</span></div>
                                    </div>
                                </div>
                                <div class="lrw-item">
                                    <div class="lrw-item-l">
                                        <img src="{{asset('panel/img/flag-spain.png')}}" class="img-fluid flag-icon" alt="Spain" />
                                        <div class="lrw-item-date-name">
                                            <div class="lrw-item-date">15min ago</div>
                                            <div class="lrw-item-name">Juan Pedro</div>
                                        </div>
                                    </div>
                                    <div class="lrw-item-r">
                                        <div class="lrw-item-score"><span>IQ Score:</span><span class="lrq-score-val">84</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="last-results-wrapper-col col-lg-4">
                            <div class="lrw-col-content">
                                <div class="lrw-item">
                                    <div class="lrw-item-l">
                                        <img src="{{asset('panel/img/flag-spain.png')}}" class="img-fluid flag-icon" alt="Spain" />
                                        <div class="lrw-item-date-name">
                                            <div class="lrw-item-date">17min ago</div>
                                            <div class="lrw-item-name">Carlos Pepito</div>
                                        </div>
                                    </div>
                                    <div class="lrw-item-r">
                                        <div class="lrw-item-score"><span>IQ Score:</span><span class="lrq-score-val">69</span></div>
                                    </div>
                                </div>
                                <div class="lrw-item">
                                    <div class="lrw-item-l">
                                        <img src="{{asset('panel/img/flag-spain.png')}}" class="img-fluid flag-icon" alt="Spain" />
                                        <div class="lrw-item-date-name">
                                            <div class="lrw-item-date">20min ago</div>
                                            <div class="lrw-item-name">Ines Gonzales</div>
                                        </div>
                                    </div>
                                    <div class="lrw-item-r">
                                        <div class="lrw-item-score"><span>IQ Score:</span><span class="lrq-score-val">77</span></div>
                                    </div>
                                </div>
                                <div class="lrw-item">
                                    <div class="lrw-item-l">
                                        <img src="{{asset('panel/img/flag-spain.png')}}" class="img-fluid flag-icon" alt="Spain" />

                                        <div class="lrw-item-date-name">
                                            <div class="lrw-item-date">25min ago</div>
                                            <div class="lrw-item-name">Diego Carvahlo</div>
                                        </div>
                                    </div>
                                    <div class="lrw-item-r">
                                        <div class="lrw-item-score"><span>IQ Score:</span><span class="lrq-score-val">80</span></div>
                                    </div>
                                </div>
                                <div class="lrw-item">
                                    <div class="lrw-item-l">
                                        <img src="{{asset('panel/img/flag-spain.png')}}" class="img-fluid flag-icon" alt="Spain" />
                                        <div class="lrw-item-date-name">
                                            <div class="lrw-item-date">28min ago</div>
                                            <div class="lrw-item-name">Juan Pedro</div>
                                        </div>
                                    </div>
                                    <div class="lrw-item-r">
                                        <div class="lrw-item-score"><span>IQ Score:</span><span class="lrq-score-val">108</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="content-section home-about-section">
        <div class="container">
            <div class="s-content last-results-content">
                <div class="sc-title-wrapper text-center">
                    <h2 class="section-title">World Wide IQ Test</h2>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-padding-right-d">
                        <p class="home-about-text">The World Wide IQ Test is part of an ambitious effort to deliver fun, stimulating and engaging online measures of human cognitive abilities, as well as social and emotional learning skills for the global community. We aim to provide you with accurate and precise information about important aspects of your intellectual abilities and personality characteristics, and where they may benefit the most from further development, regardless of your academic, professional, or cultural background. The current version of the World Wide IQ Test measures several dimensions of general fluid intelligence, including visuospatial pattern reasoning, visuospatial insight, and numerical pattern reasoning skills.</p>
                    </div>
                    <div class="col-lg-6">
                        <img src="{{asset('panel/img/change-illustration.png')}}" class="img-fluid" alt="Spain" />

                    </div>
                </div>
                <div class="row home-about-row">
                    <div class="col-lg-4">
                        <div class="home-about-col col-m-mb">
                            <div class="hac-number">1.</div>
                            <div class="hac-title">Take the IQ Test</div>
                            <div class="hac-text">Designed by expert psychologists and test developers</div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="home-about-col col-m-mb">
                            <div class="hac-number">2.</div>
                            <div class="hac-title">Find out your scores</div>
                            <div class="hac-text">Get your customized score report and learn how you compare to thousands of adults from all over the world</div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="home-about-col">
                            <div class="hac-number">3.</div>
                            <div class="hac-title">Tell your friends all about it</div>
                            <div class="hac-text">Challenge your friends to a battle of the brains!</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="content-section home-about-section c-section-bg">
        <div class="container">
            <div class="s-content last-results-content">
                <div class="row">
                    <div class="col-lg-4 col-padding-right-d">
                        <div class="sc-title-wrapper sc-title-padding-s">
                            <h2 class="section-title section-title-s">Score Distribution</h2>
                        </div>
                        <p class="score-distribution-text">The World Wide IQ Test presents you with a short series of fun, challenging problems that are designed to measure your fluid intelligence abilities and provide you with both accurate and precise scores. You can take the test online anytime from any mobile device or desktop computer in a comfortable, relaxed setting, and immediately receive a detailed score report that tells you how your performance compares to thousands of adults from all over the world and helps you identify areas for further development.</p>
                    </div>
                    <div class="col-lg-8">
                        <h4 class="chart-title">Distribution of IQ in the world population</h4>
                        <div id="worldPopulationChart"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="before-footer-cta-wrapper">
        <div class="container">
            <div class="before-footer-cta-content">
                <div class="before-footer-cta-text">
                    <span>Take this IQ test and check <br><span class="footer-cta-typed"></span></span>
                </div>
                <div class="before-footer-cta-btn-wrapper">
                    <a href="quizz" class="cta-btn cta-btn-xl animate__animated animate__pulse animate__infinite">
                        <span>Start IQ Test</span>
                        <img src="{{asset('panel/img/icons/login-3.svg')}}" class="img-fluid svg-icon icon-white cta-btn-icon" alt="Icon Go" />
                    </a>
                </div>
            </div>
        </div>
    </div>

@endsection
