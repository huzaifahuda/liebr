@extends('frontend.layouts.main')
@section('main-container')

    <div class="container">
        <div class="quiz-content-algn">
            <div class="quiz-header-wrapper animate__animated animate__bounceIn">
                <div class="qhw-left">
                    <h2 class="quiz-test-name">Quiz Test 1</h2>
                </div>
                <div class="qhw-right">
                    <img src="{{asset('panel/img/icons/history-2.svg')}}" class="img-fluid quiz-timer-icon" alt="Time Left:">
                    <span id="quiz-timer">20:00</span>
                </div>
            </div>
            <div class="quiz-wrapper">
                <div class="quiz-questions-wrapper animate__animated animate__bounceIn animation-delay-200">
                    <div class="quiz-questions-content">
                        <div class="quiz-question quiz-question-1 qv">
                            <h3>Which Shape is missing?</h3>
                            <img src="{{asset('panel/img/question-1.png')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-2 qnv">
                            <h3>How many triangles are in the picture?</h3>
                            <img src="{{asset('panel/img/question-2.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-3 qnv">
                            <h3>Which Shape is missing?</h3>
                            <img src="{{asset('panel/img/question-3.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-4 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-4.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-5 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-5.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-6 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-6.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-7 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-7.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-8 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-8.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-9 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-9.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-10 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-10.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-11 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-11.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-12 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-12.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-13 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-13.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-14 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-14.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-15 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-15.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-16 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-16.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-17 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-17.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-18 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-18.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-19 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-19.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-20 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-20.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-21 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-21.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                        <div class="quiz-question quiz-question-22 qnv">
                            <h3>Which number is missing?</h3>
                            <img src="{{asset('panel/img/question-22.svg')}}" alt="" class="img-fluid quiz-question-img" />
                        </div>
                    </div>
                </div>
                <div class="quiz-answers-wrapper animate__animated animate__bounceIn animation-delay-400">
                    <div class="quiz-answers-content">
                        <div class="quiz-answers quiz-answers-1 qv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-1-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-1-1.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-1-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-1-2.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-1-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-1-1.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-1-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-1-2.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-1-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-1-1.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-1-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-1-2.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="quiz-answers quiz-answers-2 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-2-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-2-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-2-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-2-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-2-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-2-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-2-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-2-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-2-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-2-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-2-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-2-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="quiz-answers quiz-answers-3 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-3-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-3-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-3-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-3-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-3-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-3-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-3-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-3-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-3-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-3-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-3-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-3-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-4 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-4-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-4-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-4-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-4-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-4-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-4-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-4-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-4-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-4-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-4-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-4-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-4-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-5 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-5-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-5-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-5-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-5-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-5-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-5-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-5-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-5-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-5-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-5-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-5-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-5-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="quiz-answers quiz-answers-6 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-6-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-6-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-6-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-6-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-6-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-6-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-6-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-6-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-6-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-6-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-6-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-6-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-7 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-7-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-7-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-7-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-7-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-7-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-7-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-7-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-7-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-7-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-7-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-7-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-7-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-8 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-8-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-8-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-8-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-8-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-8-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-8-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-8-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-8-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-8-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-8-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-8-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-8-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-9 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-9-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-9-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-9-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-9-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-9-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-9-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-9-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-9-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-9-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-9-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-9-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-9-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-10 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-10-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-10-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-10-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-10-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-10-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-10-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-10-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-10-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-10-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-10-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-10-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-10-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-11 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-11-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-11-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-11-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-11-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-11-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-11-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-11-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-11-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-11-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-11-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-11-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-11-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-12 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-12-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-12-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-12-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-12-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-12-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-12-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-12-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-12-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-12-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-12-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-12-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-12-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-13 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-13-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-13-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-13-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-13-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-13-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-13-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-13-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-13-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-13-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-13-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-13-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-13-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-14 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-14-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-14-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-14-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-14-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-14-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-14-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-14-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-14-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-14-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-14-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-14-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-14-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-15 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-15-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-15-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-15-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-15-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-15-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-15-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-15-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-15-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-15-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-15-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-15-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-15-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-16 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-16-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-16-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-16-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-16-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-16-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-16-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-16-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-16-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-16-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-16-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-16-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-16-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-17 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-17-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-17-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-17-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-17-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-17-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-17-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-17-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-17-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-17-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-17-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-17-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-17-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-18 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-18-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-18-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-18-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-18-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-18-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-18-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-18-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-18-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-18-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-18-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-18-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-18-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-19 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-19-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-19-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-19-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-19-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-19-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-19-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-19-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-19-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-19-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-19-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-19-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-19-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-20 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-20-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-20-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-20-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-20-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-20-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-20-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-20-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-20-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-20-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-20-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-20-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-20-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-21 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-21-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-21-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-21-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-21-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-21-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-21-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-21-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-21-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-21-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-21-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-21-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-21-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="quiz-answers quiz-answers-22 qnv">
                            <h3>Please choose an answer:</h3>
                            <div class="quiz-answers-h">
                                <div class="quiz-answer quiz-answer-22-1">
                                    <div class="quiz-answer-content">
                                        <span>A)</span>
                                        <img src="{{asset('panel/img/answer-22-a.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-22-1">
                                    <div class="quiz-answer-content">
                                        <span>B)</span>
                                        <img src="{{asset('panel/img/answer-22-b.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-22-1">
                                    <div class="quiz-answer-content">
                                        <span>C)</span>
                                        <img src="{{asset('panel/img/answer-22-c.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-22-1">
                                    <div class="quiz-answer-content">
                                        <span>D)</span>
                                        <img src="{{asset('panel/img/answer-22-d.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-22-1">
                                    <div class="quiz-answer-content">
                                        <span>E)</span>
                                        <img src="{{asset('panel/img/answer-22-e.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                                <div class="quiz-answer quiz-answer-22-1">
                                    <div class="quiz-answer-content">
                                        <span>F)</span>
                                        <img src="{{asset('panel/img/answer-22-f.png')}}" alt="" class="img-fluid quiz-answer-img" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="quiz-nav-wrapper animate__animated animate__bounceIn animation-delay-600">
                <div class="quiz-nav-content">
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-1 current">
                            <span>1</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-2">
                            <span>2</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-3">
                            <span>3</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-4">
                            <span>4</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-5">
                            <span>5</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-6">
                            <span>6</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-7">
                            <span>7</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-8">
                            <span>8</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-9">
                            <span>9</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-10">
                            <span>10</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-11">
                            <span>11</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-12">
                            <span>12</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-13">
                            <span>13</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-14">
                            <span>14</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-15">
                            <span>15</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-16">
                            <span>16</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-17">
                            <span>17</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-18">
                            <span>18</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-19">
                            <span>19</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-20">
                            <span>20</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-21">
                            <span>21</span>
                        </div>
                    </div>
                    <div class="quiz-nav-item-wrapper">
                        <div class="quiz-nav-item quiz-nav-item-cb quiz-nav-item-22">
                            <span>22</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
