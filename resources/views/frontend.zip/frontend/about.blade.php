@extends('frontend.layouts.main')
@section('main-container')

<section class="subpage-title-wrapper c-section-bg">
    <div class="container">
        <div class="breadcrumbs-wrapper">
            <ul class="breadcrumbs">
                <li><a href="index">Home</a></li>
                <li class="breadcrumb-current"><span>About Us</span></li>
            </ul>
        </div>
        <h1 class="subpage-title">About Us</h1>
        <span class="subpage-subtitle">Find out more about who we are and what we do</span>
    </div>
</section>
<section class="content-section subpage-section">
    <div class="container">
        <div class="s-content">
            <div class="about-container standard-content-container">
                <div class="about-section-first">
                    <div class="row row-dm">
                        <div class="col-lg-6 col-12 col-dp">
                            <div class="standard-content-title-wrapper">
                                <h2 class="standard-content-title">About iQ-Certify.com</h2>
                            </div>
                            <p class="about-intro-text">The IQ Certify Test is part of an ambitious effort to deliver fun, stimulating, and engaging online measures of human cognitive abilities, as well as social and emotional learning skills for the global community. We aim to provide adult test takers from around the world, regardless of their academic, professional, or cultural linguistic background, with accurate, precise information about important aspects of their intellectual abilities and where they may benefit the most from further development.</p>
                        </div>
                        <div class="col-lg-6 col-12 col-dp">
                            <img src="{{asset('panel/img/about-us-img.png')}}" class="img-fluid about-us-img" alt="" />
                        </div>
                    </div>
                </div>
                <div class="about-section-second">
                    <div class="test-info-columns">
                        <div class="row row-dm">
                            <div class="col-lg-4 col-12 col-dp col-m-mb">
                                <div class="test-info-col">
                                    <div class="test-info-col-icon-wrapper">
                                        <div class="test-info-col-icon-content">
                                            <div class="test-info-col-icon-circle"></div>
                                            <img src="{{asset('panel/img/icons/about-us-icon-1.svg')}}" class="img-fluid test-info-col-icon" alt="" />
                                        </div>
                                    </div>
                                    <h3>Start the IQ Test</h3>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam vestibulum risus eu risus molestie.</p>
                                </div>
                            </div>
                            <div class="col-lg-4 col-12 col-dp col-m-mb">
                                <div class="test-info-col">
                                    <div class="test-info-col-icon-wrapper">
                                        <div class="test-info-col-icon-content">
                                            <div class="test-info-col-icon-circle"></div>
                                            <img src="{{asset('panel/img/icons/about-us-icon-2.svg')}}" class="img-fluid test-info-col-icon" alt="" />
                                        </div>
                                    </div>
                                    <h3>Download your report</h3>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam vestibulum risus eu risus molestie.</p>
                                </div>
                            </div>
                            <div class="col-lg-4 col-12 col-dp">
                                <div class="test-info-col">
                                    <div class="test-info-col-icon-wrapper">
                                        <div class="test-info-col-icon-content">
                                            <div class="test-info-col-icon-circle"></div>
                                            <img src="{{asset('panel/img/icons/about-us-icon-3.svg')}}" class="img-fluid test-info-col-icon" alt="" />
                                        </div>
                                    </div>
                                    <h3>Analyize your IQ</h3>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam vestibulum risus eu risus molestie.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="before-footer-cta-wrapper">
    <div class="container">
        <div class="before-footer-cta-content">
            <div class="before-footer-cta-text">
                <span>Take this IQ test and check <br><span class="footer-cta-typed"></span></span>
            </div>
            <div class="before-footer-cta-btn-wrapper">
                <a href="quizz" class="cta-btn cta-btn-xl animate__animated animate__pulse animate__infinite">
                    <span>Start IQ Test</span>
                    <img src="{{asset('panel/img/icons/login-3.svg')}}" class="img-fluid svg-icon icon-white cta-btn-icon" alt="Icon Go" />
                </a>
            </div>
        </div>
    </div>
</div>
@endsection
