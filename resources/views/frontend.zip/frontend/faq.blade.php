@extends('frontend.layouts.main')
@section('main-container')

<section class="subpage-title-wrapper c-section-bg">
    <div class="container">
        <div class="breadcrumbs-wrapper">
            <ul class="breadcrumbs">
                <li><a href="index">Home</a></li>
                <li class="breadcrumb-current"><span>FAQ</span></li>
            </ul>
        </div>
        <h1 class="subpage-title">Frequently Asked Questions</h1>
        <span class="subpage-subtitle">Here are answers to frequently asked questions about the World Wide IQ Test</span>
    </div>
</section>
<section class="content-section subpage-section">
    <div class="container">
        <div class="s-content">
            <div class="faq-container">
                <div class="accordion faq-content" id="accordionFAQ">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-1" aria-expanded="true" aria-controls="faq-item-1">
                                <span>1.</span> What is IQ?
                            </button>
                        </h2>
                        <div id="faq-item-1" class="accordion-collapse collapse show" data-bs-parent="#accordionFAQ">
                            <div class="accordion-body">
                                <p>
                                    IQ, short for “Intelligence Quotient”, is a score that is considered to measure one or more aspects of human intelligence. Human intelligence encompasses many different types of knowledge, skills, and abilities that underlie our capacity to effectively navigate and make sense of the world around us, as well as to solve a wide range of problems. No single score can fully capture all aspects of human intelligence; however, scientists have developed very good methods for accurately and precisely estimating fundamental aspects of human intelligence, such as an individual’s ability to reason and think logically, process sensory information, solve mathematics problems, read and comprehend texts, etc. Numerous research studies have also shown that IQ measures can be good predictors of success in academic and workforce settings, and useful for diagnosing learning disabilities.
                                </p>
                                <p>
                                    Human intelligence is, by its very nature, an abstract concept, and, therefore, it can only be defined in relative terms. That is, there is no universally-accepted definition or absolute standard for human intelligence. IQ scores, therefore, are designed to provide a means of comparing an individual’s mental abilities in relation to the general population, or to a specific segment of the general population (e.g., one’s age group). Typically, IQ scores are standardized such that a score of 100 represents the average score for a population and approximately two-thirds of the entire population receive scores ranging from 85 to 115. The remaining third of the population have IQs that are well above or below the population average.
                                </p>
                                <p>
                                    It is important to emphasize that while IQ scores can provide a good measure of an individual’s intellectual abilities, they are far from perfect. For instance, a person may be distracted or tired when taking an IQ test and receive scores that underestimate his true abilities. Traditional IQ scores may also not be good indicators of social and emotional learning skills, such as how well individuals perform in social settings or manage their emotions.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-2" aria-expanded="false" aria-controls="faq-item-2">
                                <span>2.</span> How is IQ measured?
                            </button>
                        </h2>
                        <div id="faq-item-2" class="accordion-collapse collapse" data-bs-parent="#accordionFAQ">
                            <div class="accordion-body">
                                <p>
                                    IQ is typically measured using tests designed to assess one or more aspects of an individual’s intelligence. These aspects may include mental abilities such as reasoning and logical thinking, visuospatial reasoning, short-term or working memory, quantitative reasoning, or verbal knowledge and reasoning.
                                </p>
                                <p>
                                    IQ tests can be administered by computer, in pencil and paper formats, or one-on-one by a professional psychologist, and may take anywhere from a few minutes to several hours to complete, depending on the types of knowledge, skills, and abilities being evaluated.
                                </p>
                                <p>
                                    The World Wide IQ Test is administered entirely online and is currently designed to measure key aspects of an individual’s general “fluid intelligence”. Fluid Intelligence refers to a broad set of mental abilities that require little or no prior learning or experience. These include solving abstract reasoning problems or recognizing logical patterns or relations among shapes, numbers, or letters. They are so-called “fluid” abilities in the sense that they are considered to “flow into” or support a wide range of other intellectual abilities. Individuals who are high in fluid intelligence tend to perform well in academic and work environments, especially under conditions characterized by uncertainty, ambiguity, complexity, and time pressure.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-3" aria-expanded="false" aria-controls="faq-item-3">
                                <span>3.</span> How is my IQ score calculated?
                            </button>
                        </h2>
                        <div id="faq-item-3" class="accordion-collapse collapse" data-bs-parent="#accordionFAQ">
                            <div class="accordion-body">
                                <p>After completing an <a href="https://LINK">IQ test</a>, your answers are graded and converted to standardized scale scores that allow you to compare your performance to others who completed the same test under similar conditions. </p>
                                <p>In the case of the World Wide IQ Test, your test results may be compared to those of thousands of adults from around the world who already completed the test. As with most IQ tests, scores from the World Wide IQ test are standardized such that a score of 100 represents the average score for the population of adults worldwide who completed the test and approximately two-thirds of this entire population receive scores ranging from 85 to 115.</p>
                                <p>The remaining third of the population have IQs that are well above or below the population average. The chart below shows IQ scores along with their corresponding percentile ranges in the population.</p>
                                <table width="0">
                                    <tbody>
                                    <tr>
                                        <td width="50%">
                                            <strong>IQ Scale</strong>
                                        </td>
                                        <td width="50%">
                                            <strong>Percentile Range</strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="50%">Above 130</td>
                                        <td width="50%">99</td>
                                    </tr>
                                    <tr>
                                        <td width="50%">116 – 130</td>
                                        <td width="50%">68 – 98</td>
                                    </tr>
                                    <tr>
                                        <td width="50%">101 – 115</td>
                                        <td width="50%">51 – 67</td>
                                    </tr>
                                    <tr>
                                        <td width="50%">100</td>
                                        <td width="50%">50</td>
                                    </tr>
                                    <tr>
                                        <td width="50%">85 – 99</td>
                                        <td width="50%">33 – 49</td>
                                    </tr>
                                    <tr>
                                        <td width="50%">70 – 84</td>
                                        <td width="50%">2 – 32</td>
                                    </tr>
                                    <tr>
                                        <td width="50%">Below 70</td>
                                        <td width="50%">1</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-4" aria-expanded="false" aria-controls="faq-item-4">
                                <span>4.</span> Can I increase my IQ?
                            </button>
                        </h2>
                        <div id="faq-item-4" class="accordion-collapse collapse" data-bs-parent="#accordionFAQ">
                            <div class="accordion-body">
                                <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-5" aria-expanded="false" aria-controls="faq-item-5">
                                <span>5.</span> Why should I take the World Wide IQ Test?
                            </button>
                        </h2>
                        <div id="faq-item-5" class="accordion-collapse collapse" data-bs-parent="#accordionFAQ">
                            <div class="accordion-body">
                                <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-6" aria-expanded="false" aria-controls="faq-item-6">
                                <span>6.</span> Does time affect my results?
                            </button>
                        </h2>
                        <div id="faq-item-6" class="accordion-collapse collapse" data-bs-parent="#accordionFAQ">
                            <div class="accordion-body">
                                <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-7" aria-expanded="false" aria-controls="faq-item-7">
                                <span>7.</span> How old do I have to be to take the test?
                            </button>
                        </h2>
                        <div id="faq-item-7" class="accordion-collapse collapse" data-bs-parent="#accordionFAQ">
                            <div class="accordion-body">
                                <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-8" aria-expanded="false" aria-controls="faq-item-8">
                                <span>8.</span> Does the test cost money?
                            </button>
                        </h2>
                        <div id="faq-item-8" class="accordion-collapse collapse" data-bs-parent="#accordionFAQ">
                            <div class="accordion-body">
                                <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-9" aria-expanded="false" aria-controls="faq-item-9">
                                <span>9.</span> How can I pay for the IQ Report and certificate?
                            </button>
                        </h2>
                        <div id="faq-item-9" class="accordion-collapse collapse" data-bs-parent="#accordionFAQ">
                            <div class="accordion-body">
                                <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-10" aria-expanded="false" aria-controls="faq-item-10">
                                <span>10.</span> I paid but didn’t receive the results
                            </button>
                        </h2>
                        <div id="faq-item-10" class="accordion-collapse collapse" data-bs-parent="#accordionFAQ">
                            <div class="accordion-body">
                                <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-11" aria-expanded="false" aria-controls="faq-item-11">
                                <span>11.</span> Can I see the correct answers to my test?
                            </button>
                        </h2>
                        <div id="faq-item-11" class="accordion-collapse collapse" data-bs-parent="#accordionFAQ">
                            <div class="accordion-body">
                                <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-item-12" aria-expanded="false" aria-controls="faq-item-12">
                                <span>12.</span> I can’t open my report and certificate.
                            </button>
                        </h2>
                        <div id="faq-item-12" class="accordion-collapse collapse" data-bs-parent="#accordionFAQ">
                            <div class="accordion-body">
                                <p>The Report and Certificate are delivered in PDF format. Should you not be able to view or open the files, you can download the PDF viewer <a href="https://get.adobe.com/reader/" target="_blank" rel="noopener">here</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="before-footer-cta-wrapper">
    <div class="container">
        <div class="before-footer-cta-content">
            <div class="before-footer-cta-text">
                <span>Take this IQ test and check <br><span class="footer-cta-typed"></span></span>
            </div>
            <div class="before-footer-cta-btn-wrapper">
                <a href="quizz" class="cta-btn cta-btn-xl animate__animated animate__pulse animate__infinite">
                    <span>Start IQ Test</span>
                    <img src="{{asset('panel/img/icons/login-3.svg')}}" class="img-fluid svg-icon icon-white cta-btn-icon" alt="Icon Go" />
                </a>
            </div>
        </div>
    </div>
</div>

@endsection
