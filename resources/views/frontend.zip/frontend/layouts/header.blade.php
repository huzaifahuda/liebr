<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
    <title>IQ Cerify - Take an IQ test now and get your Certify IQ</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="Would you like to know your IQ? Take an IQ Test now and get the results instantly, you will obtain a diploma and a performance analysis of your intellectual capacity." />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="icon" type="image/ico" href="{{asset('panel/img/favicon.ico')}}" />
    <!-- Open Graph Meta Tags-->
    <meta property="og:title" content="Would you like to know your IQ? Take an IQ Test now and get the results instantly, you will obtain a diploma and a performance analysis of your intellectual capacity." />
    <meta property="og:description" content="Would you like to know your IQ? Take an IQ Test now and get the results instantly, you will obtain a diploma and a performance analysis of your intellectual capacity." />
    <meta property="og:type" content="IQ Certify" />
    <meta property="og:url" content="https://www.iq-certify.com/" />
    <meta property="og:image" content="https://iq-certify.com/img/hero-img.png" />
    <!-- Twitter Meta -->
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@tweetname" />
    <meta name="twitter:title" content="IQ Cerify - Take an IQ test now and get your Certify IQ" />
    <meta name="twitter:description" content="Would you like to know your IQ? Take an IQ Test now and get the results instantly, you will obtain a diploma and a performance analysis of your intellectual capacity." />
    <meta name="twitter:image" content="https://iq-certify.com/img/hero-img.png" />
    <!-- Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons|Material+Icons+Two+Tone|" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,opsz,wght@0,6..12,300;0,6..12,400;0,6..12,500;0,6..12,600;0,6..12,700;0,6..12,800;0,6..12,900;1,6..12,400;1,6..12,700&display=swap" rel="stylesheet">

    <!-- CSS -->
    <link href="{{asset('panel/css/bootstrap.min.css')}}" rel="stylesheet" />
    <link href="{{asset('panel/css/animate.min.css')}}" rel="stylesheet" />
    <link href="{{asset('panel/css/magnific-popup.css')}}" rel="stylesheet" />
    <link href="{{asset('panel/css/jquery.flipbox.css')}}" rel="stylesheet" />
    <link href="{{asset('panel/css/style.css')}}" rel="stylesheet" />
</head>
<body>

<header>
    <div class="container">
        <div class="header-content">
            <div class="logo-wrapper">
                <a href="{{url('/')}}"><img src="{{asset('panel/img/logo.png')}}" class="img-fluid logo-img" alt="Website Logo" /></a>
            </div>
            <span class="toggle-button">
				 <div class="menu-bar menu-bar-top"></div>
				 <div class="menu-bar menu-bar-middle"></div>
				 <div class="menu-bar menu-bar-bottom"></div>
			</span>
            <div class="nav-wrapper">
                <h4 class="mobile-nav-header">Navigation</h4>
                <div class="nav-content">
                    <ul class="nav">
                        <li class="nav-button"><a href="{{url('/')}}">Home</a></li>
{{--                        <li><a href="{{url('')}}">About</a></li>--}}
{{--                        <li><a href="{{url('')}}">IQ Report (Demo)</a></li>--}}
                        <li class="nav-button"><a href="{{url('/faq')}}">FAQ</a></li>
                        <li class="nav-button"><a href="{{url('/about')}}">About</a></li>
                        <li class="nav-button"><a href="{{url('/contact')}}">Contact</a></li>
                        <li class="nav-button"><a id="auth-trigger" href="{{url('/quizz')}}">Start IQ Test</a></li>

                        <li class="nav-button">
                            @if (Route::has('login'))
                                <div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
                                    @auth
                                        <a href="{{ url('/dashboard') }}" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Dashboard</a>
                                    @else
                                        <a href="{{ route('login') }}" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Log in</a>

                                        @if (Route::has('register'))
                                            <a href="{{ route('register') }}" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Register</a>
                                        @endif
                                    @endauth
                                </div>
                            @endif
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>
